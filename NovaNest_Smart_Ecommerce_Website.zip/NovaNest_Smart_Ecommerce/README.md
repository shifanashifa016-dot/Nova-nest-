# NOVA NEST — Smart E-commerce Shopping Website

A responsive, modern e-commerce storefront built using HTML, CSS and vanilla JavaScript.

## Features
- Modern editorial-style landing page and category collections
- Product catalogue with category filters
- Live product search
- Sort products by price (low to high / high to low)
- Add to bag, quantity controls, remove items and live subtotal
- Wishlist with add/remove functionality
- Responsive layout for desktop, tablet and mobile
- Newsletter form interaction
- Demo checkout modal (no real payment gateway connected)

## How to run
1. Download and extract the ZIP file.
2. Open the `index.html` file in any modern web browser.
3. Internet is required for Google Fonts and the product photography hosted by Unsplash.

## Project structure
- `index.html` — website structure and content
- `style.css` — styling, layout, animations and responsive design
- `script.js` — product data and interactive shopping features

## Note
This is a front-end academic prototype. It does not connect to a real database, user account system, inventory service or payment gateway.
