const products = [
 {id:1,name:"Sunday Ceramic Vase",category:"Home",price:899,tag:"BESTSELLER",image:"https://images.unsplash.com/photo-1578500494198-246f612d3b3d?auto=format&fit=crop&w=700&q=80"},
 {id:2,name:"Cloud Nine Tote",category:"Style",price:649,tag:"JUST IN",image:"https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=700&q=80"},
 {id:3,name:"Pebble Mini Speaker",category:"Tech",price:1499,tag:"GOOD PICK",image:"https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=700&q=80"},
 {id:4,name:"Soft Morning Lamp",category:"Home",price:1299,tag:"EDITOR'S PICK",image:"https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=700&q=80"},
 {id:5,name:"Everyday Mini Sling",category:"Style",price:1099,tag:"JUST IN",image:"https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=700&q=80"},
 {id:6,name:"Studio Wireless Buds",category:"Tech",price:1899,tag:"SMART FIND",image:"https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=700&q=80"},
 {id:7,name:"Calm Days Candle",category:"Home",price:499,tag:"LITTLE LUXURY",image:"https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=700&q=80"},
 {id:8,name:"Retro Time Watch",category:"Style",price:1599,tag:"TIMELESS",image:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=700&q=80"}
];
let cart = [], wishlist = [], activeFilter = "All", searchTerm = "";
const $ = id => document.getElementById(id);
const money = n => "₹" + n.toLocaleString("en-IN");

function renderProducts(){
 let list = products.filter(p => (activeFilter==="All" || p.category===activeFilter) && (p.name.toLowerCase().includes(searchTerm) || p.category.toLowerCase().includes(searchTerm)));
 const sort = $("sortSelect").value;
 if(sort==="low") list.sort((a,b)=>a.price-b.price);
 if(sort==="high") list.sort((a,b)=>b.price-a.price);
 $("productGrid").innerHTML = list.map(p=>`<article class="product-card">
   <div class="product-image"><img src="${p.image}" alt="${p.name}" loading="lazy"><span class="product-tag">${p.tag}</span>
   <button class="heart-btn ${wishlist.includes(p.id)?"saved":""}" data-wish="${p.id}" aria-label="Add ${p.name} to wishlist">${wishlist.includes(p.id)?"♥":"♡"}</button></div>
   <div class="product-info"><span class="product-category">${p.category} / NOVA PICK</span><h3>${p.name}</h3>
   <div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-btn" data-add="${p.id}">ADD TO BAG +</button></div></div></article>`).join("");
 $("emptyState").hidden = list.length>0;
}
function updateCounts(){
 $("cartCount").textContent=cart.reduce((s,x)=>s+x.qty,0);
 $("drawerCount").textContent=`(${cart.reduce((s,x)=>s+x.qty,0)})`;
 $("wishCount").textContent=wishlist.length;
 $("wishlistDrawerCount").textContent=`(${wishlist.length})`;
}
function renderCart(){
 $("cartItems").innerHTML = cart.length ? cart.map(item=>{const p=products.find(x=>x.id===item.id);return `<div class="cart-row"><img src="${p.image}" alt="${p.name}"><div><h4>${p.name}</h4><p>${money(p.price)}</p><div class="qty-controls"><button data-qty="${p.id}" data-change="-1">−</button><span>${item.qty}</span><button data-qty="${p.id}" data-change="1">+</button></div><button class="remove-btn" data-remove="${p.id}">Remove</button></div><b>${money(p.price*item.qty)}</b></div>`}).join("") : `<div class="drawer-empty"><b>✳</b>Your bag is feeling light.<br>Let's find it something lovely.</div>`;
 const total=cart.reduce((s,x)=>s+products.find(p=>p.id===x.id).price*x.qty,0);
 $("subtotal").textContent=money(total); $("modalTotal").textContent=money(total); updateCounts();
}
function renderWishlist(){
 $("wishlistItems").innerHTML=wishlist.length?wishlist.map(id=>{const p=products.find(x=>x.id===id);return `<div class="cart-row"><img src="${p.image}" alt="${p.name}"><div><h4>${p.name}</h4><p>${money(p.price)}</p><button class="add-btn" data-add="${p.id}">ADD TO BAG +</button></div><button class="remove-btn" data-unwish="${p.id}">Remove</button></div>`}).join(""):`<div class="drawer-empty"><b>♡</b>Your wishlist is waiting<br>for a little love.</div>`;
 updateCounts();
}
function openDrawer(id){$(id).classList.add("open");$("overlay").classList.add("show");document.body.style.overflow="hidden"}
function closeAll(){$("cartDrawer").classList.remove("open");$("wishlistDrawer").classList.remove("open");$("overlay").classList.remove("show");$("checkoutModal").classList.remove("open");document.body.style.overflow=""}
function toast(message){$("toast").textContent=message;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),1800)}
function addToCart(id){const item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({id,qty:1});renderCart();toast("Added to your bag ✳")}
function toggleWish(id){wishlist=wishlist.includes(id)?wishlist.filter(x=>x!==id):[...wishlist,id];renderProducts();renderWishlist();toast(wishlist.includes(id)?"Saved to your wishlist ♡":"Removed from wishlist")}
$("productGrid").addEventListener("click",e=>{const add=e.target.closest("[data-add]"),wish=e.target.closest("[data-wish]");if(add)addToCart(+add.dataset.add);if(wish)toggleWish(+wish.dataset.wish)});
$("cartItems").addEventListener("click",e=>{const q=e.target.closest("[data-qty]"),r=e.target.closest("[data-remove]");if(q){const item=cart.find(x=>x.id===+q.dataset.qty);item.qty+=+q.dataset.change;if(item.qty<=0)cart=cart.filter(x=>x!==item);renderCart()}if(r){cart=cart.filter(x=>x.id!==+r.dataset.remove);renderCart()}});
$("wishlistItems").addEventListener("click",e=>{const u=e.target.closest("[data-unwish]"),a=e.target.closest("[data-add]");if(u)toggleWish(+u.dataset.unwish);if(a)addToCart(+a.dataset.add)});
$("filters").addEventListener("click",e=>{const b=e.target.closest("[data-filter]");if(!b)return;activeFilter=b.dataset.filter;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderProducts()});
document.querySelectorAll(".collection-card").forEach(card=>card.addEventListener("click",()=>{activeFilter=card.dataset.category;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x.dataset.filter===activeFilter));renderProducts()}));
$("searchInput").addEventListener("input",e=>{searchTerm=e.target.value.toLowerCase().trim();renderProducts()});
$("sortSelect").addEventListener("change",renderProducts);
$("cartToggle").addEventListener("click",()=>{renderCart();openDrawer("cartDrawer")});
$("wishlistToggle").addEventListener("click",()=>{renderWishlist();openDrawer("wishlistDrawer")});
$("searchToggle").addEventListener("click",()=>{$("searchInput").focus();$("shop").scrollIntoView({behavior:"smooth"})});
$("overlay").addEventListener("click",closeAll);
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",closeAll));
$("checkoutBtn").addEventListener("click",()=>{if(!cart.length){toast("Your bag is empty");return}closeAll();$("checkoutModal").classList.add("open");document.body.style.overflow="hidden"});
document.querySelector("[data-modal-close]").addEventListener("click",closeAll);
$("finishDemo").addEventListener("click",()=>{cart=[];renderCart();closeAll();toast("Thanks for exploring NOVA NEST ✳")});
$("newsletterForm").addEventListener("submit",e=>{e.preventDefault();$("newsletterMessage").textContent="You're on the list — good things are coming! ✳";$("emailInput").value=""});
$("menuToggle").addEventListener("click",()=>{document.querySelector(".desktop-nav").classList.toggle("mobile-open");const nav=document.querySelector(".desktop-nav");nav.style.display=nav.style.display==="flex"?"none":"flex";nav.style.position="absolute";nav.style.top="70px";nav.style.left="0";nav.style.right="0";nav.style.padding="20px";nav.style.background="var(--cream)";nav.style.justifyContent="center";nav.style.zIndex="25"});
renderProducts();renderCart();renderWishlist();
